
public interface Zipleme {
	public String ziple();

}
