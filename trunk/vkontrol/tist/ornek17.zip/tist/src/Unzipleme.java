
public interface Unzipleme {
	public String unziple();

}
